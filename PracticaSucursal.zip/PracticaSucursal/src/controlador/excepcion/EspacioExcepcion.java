/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.excepcion;

/**
 *
 * @author Usuario
 */
public class EspacioExcepcion extends Exception{

    public EspacioExcepcion() {
    }

    public EspacioExcepcion(String msg) {
        super(msg);
    }
}

